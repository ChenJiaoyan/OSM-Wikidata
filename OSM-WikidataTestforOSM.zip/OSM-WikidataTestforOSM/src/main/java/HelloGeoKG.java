/**
 * Created by John on 3/15/17.
 */
public class HelloGeoKG {
    public static void main(String args[]){
        System.out.printf("This project is to study (1) the linkage between OSM and WikiData, " +
                "(2) the linkage between OSM and POIs \n");
        System.out.printf("Have Fun!");
    }
}
